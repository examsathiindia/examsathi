Replace the existing tools.html in the ExamSathi GitHub repository.
This version adds a real crop editor for Passport Photo and stronger near-white background removal.
Commit message: Fix crop and image processing in student tools
